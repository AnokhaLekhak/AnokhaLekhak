<?php
/**
 * Music_Journal Theme Customizer
 *
 * @package Music_Journal
 */

/**
 * Include Playlist
 */
require trailingslashit( get_stylesheet_directory() ) . 'inc/customizer/header-media.php';

/**
 * Include Sticky Playlist
 */
require trailingslashit( get_stylesheet_directory() ) . 'inc/customizer/sticky-playlist.php';

/**
 * Include Playlist
 */
require trailingslashit( get_stylesheet_directory() ) . 'inc/customizer/playlist.php';
